python manage.py makemigrations muradefect
python manage.py migrate