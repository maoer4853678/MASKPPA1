from django.apps import AppConfig


class MuradefectConfig(AppConfig):
    name = 'muradefect'
